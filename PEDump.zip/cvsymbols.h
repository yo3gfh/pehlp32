BOOL DumpCVSymbolTable( PBYTE pRawCVSymbolData, PBYTE pFileBase  );
